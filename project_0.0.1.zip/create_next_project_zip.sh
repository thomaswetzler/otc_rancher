#!/bin/bash

# Find all existing project_*.zip files and extract version numbers
latest_version=$(ls project_*.zip 2>/dev/null | \
    sed -n 's/^project_\([0-9]\+\.[0-9]\+\.\([0-9]\+\)\)\.zip$/\1 \2/p' | \
    sort -t' ' -k2 -n | tail -n1 | cut -d' ' -f1)

# Default version if none found
if [ -z "$latest_version" ]; then
    next_version="0.0.1"
else
    base=$(echo "$latest_version" | cut -d'.' -f1,2)
    patch=$(echo "$latest_version" | cut -d'.' -f3)
    next_patch=$((patch + 1))
    next_version="$base.$next_patch"
fi

# Output filename
zip_file="project_${next_version}.zip"
echo "📦 Creating $zip_file ..."

# Create zip excluding unwanted files
zip -r "$zip_file" . \
  -x "*.git*" \
  -x "*.DS_Store" \
  -x "__pycache__/*" \
  -x "*.pyc" \
  -x "*.swp" \
  -x "project_*.zip"

echo "✅ Done."
